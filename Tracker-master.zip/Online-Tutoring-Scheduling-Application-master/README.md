# Tracker
An application used by TRIO Scholarship Program for their tutoring program where student and tutor can sign in for their session. It is also used to monitor the attendance of tutor and student, geeting different types of reports based on it.
