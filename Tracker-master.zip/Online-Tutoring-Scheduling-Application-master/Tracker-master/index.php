<?php
	header('Location: php/Adminlogon.php');
?>
